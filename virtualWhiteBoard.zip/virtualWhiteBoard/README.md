# virtualWhiteBoard

A Python based virtual whiteboard specially designed to ease explanation for people who are not or little acquainted with technology.
The virtual whiteboard has the save functionality (where one can save what one has written as image ) and is also incorporated with 2 themes (light and dark ).  
